function [result] = hp_matrix_turn(a)
    result = c_hp_matrix_turn(complex(double(a)));
end